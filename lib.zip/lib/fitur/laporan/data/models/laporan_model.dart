// Model untuk Laporan dan detailnya

class Laporan {
  final int id;
  final int userId;
  final String kategori;
  final String deskripsi;
  final String lokasi;
  final String status;
  final DetailPelapor detailPelapor;
  final DetailTerlapor detailTerlapor;
  final DetailPenerimaManfaat detailPenerimaManfaat;
  final DetailKasus detailKasus;
  final InformasiAnak informasiAnak;

  Laporan({
    required this.id,
    required this.userId,
    required this.kategori,
    required this.deskripsi,
    required this.lokasi,
    required this.status,
    required this.detailPelapor,
    required this.detailTerlapor,
    required this.detailPenerimaManfaat,
    required this.detailKasus,
    required this.informasiAnak,
  });

  factory Laporan.fromJson(Map<String, dynamic> json) {
    return Laporan(
      id: json['id'],
      userId: json['user_id'],
      kategori: json['kategori'],
      deskripsi: json['deskripsi'],
      lokasi: json['lokasi'],
      status: json['status'],
      detailPelapor: DetailPelapor.fromJson(json['detail_pelapor']),
      detailTerlapor: DetailTerlapor.fromJson(json['detail_terlapor']),
      detailPenerimaManfaat: DetailPenerimaManfaat.fromJson(
        json['detail_penerima_manfaat'],
      ),
      detailKasus: DetailKasus.fromJson(json['detail_kasus']),
      informasiAnak: InformasiAnak.fromJson(json['informasi_anak']),
    );
  }
}

// Model Detail Pelapor
class DetailPelapor {
  final String nama;
  final String alamat;
  final String kontak;

  DetailPelapor({
    required this.nama,
    required this.alamat,
    required this.kontak,
  });

  factory DetailPelapor.fromJson(Map<String, dynamic> json) {
    return DetailPelapor(
      nama: json['nama'],
      alamat: json['alamat'],
      kontak: json['kontak'],
    );
  }
}

// Model Detail Terlapor
class DetailTerlapor {
  final String nama;
  final String alamat;
  final String kontak;

  DetailTerlapor({
    required this.nama,
    required this.alamat,
    required this.kontak,
  });

  factory DetailTerlapor.fromJson(Map<String, dynamic> json) {
    return DetailTerlapor(
      nama: json['nama'],
      alamat: json['alamat'],
      kontak: json['kontak'],
    );
  }
}

// Model Detail Penerima Manfaat
class DetailPenerimaManfaat {
  final String nama;
  final String hubungan;
  final String kondisi;

  DetailPenerimaManfaat({
    required this.nama,
    required this.hubungan,
    required this.kondisi,
  });

  factory DetailPenerimaManfaat.fromJson(Map<String, dynamic> json) {
    return DetailPenerimaManfaat(
      nama: json['nama'],
      hubungan: json['hubungan'],
      kondisi: json['kondisi'],
    );
  }
}

// Model Detail Kasus
class DetailKasus {
  final String jenisKasus;
  final String kronologi;

  DetailKasus({required this.jenisKasus, required this.kronologi});

  factory DetailKasus.fromJson(Map<String, dynamic> json) {
    return DetailKasus(
      jenisKasus: json['jenis_kasus'],
      kronologi: json['kronologi'],
    );
  }
}

// Model Informasi Anak
class InformasiAnak {
  final String nama;
  final int usia;
  final String statusPendidikan;

  InformasiAnak({
    required this.nama,
    required this.usia,
    required this.statusPendidikan,
  });

  factory InformasiAnak.fromJson(Map<String, dynamic> json) {
    return InformasiAnak(
      nama: json['nama'],
      usia: json['usia'],
      statusPendidikan: json['status_pendidikan'],
    );
  }
}
