import 'package:SENTRA/fitur/laporan/screen/widget/graph.dart';
// import 'package:SENTRA/widget/maps.dart';
import 'package:flutter/material.dart';
// import '../utils/navbar.dart';
import '../widget/trackinglaporan.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int selectedIndex = 2;

  void onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });

    switch (index) {
      case 0:
        break;
      case 1:
        break;
      case 2:
        break;
      case 3:
        break;
      case 4:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Image.asset(
                      "assets/logo/icon_ijo.png",
                      width: 50,
                      height: 50,
                      fit: BoxFit.contain,
                    ),
                    Icon(
                      Icons.chat,
                      size: 28,
                      color: Colors.black54,
                    ),
                  ],
                ),
                const SizedBox(height: 15),
                const Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(Icons.wb_sunny, size: 16, color: Colors.grey),
                    const SizedBox(width: 3),
                    Text(
                      "TUES 11 JUL",
                      style: TextStyle(
                        fontFamily: "Mulish",
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: Colors.grey,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
                const Text(
                  "Overview",
                  style: TextStyle(
                    fontFamily: "Mulish",
                    fontSize: 32, fontWeight: FontWeight.bold),
                ),

                const SizedBox(height: 5),
                const Text(
                  "Tracking Laporan",
                  style: TextStyle(
                    fontFamily: "Mulish",
                    fontSize: 16,
                    fontWeight: FontWeight.normal,
                  ),
                ),
                const SizedBox(height: 5),
                TrackingLaporan(),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(color: Colors.black12, blurRadius: 6),
                    ],
                  ),
                  child: Column(
                    children: [
                      Text(
                        textAlign: TextAlign.left,
                        "Monitoring Laporan",
                        style: const TextStyle(
                          fontFamily: "Mulish",
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),LineChartScreen(),
                    ],
                  ),
                ),
                const SizedBox(height: 5),
                
                const SizedBox(height: 20),
               Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(color: Colors.black12, blurRadius: 6),
                    ],
                  ),
                  child: Column(
                    children: [
                      Text(
                        textAlign: TextAlign.left,
                        "Lokasi Kantor",
                        style: const TextStyle(
                          fontFamily: "Mulish",
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

//   Widget _buildCard(String title, IconData icon) {
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(12),
//         boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6)],
//       ),
//       child: Row(
//         children: [
//           Icon(icon, size: 28, color: Colors.green),
//           const SizedBox(width: 12),
//           Text(
//             title,
//             style: const TextStyle(
//               fontFamily: "Mulish",
//               fontSize: 16, fontWeight: FontWeight.bold),
//           ),
//         ],
//       ),
      
//     );
//   }
}

