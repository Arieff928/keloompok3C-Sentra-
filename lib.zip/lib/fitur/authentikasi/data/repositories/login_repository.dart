import 'package:dio/dio.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/network/endpoints.dart';

class AuthRepository {
  Future<Response> login(String notelp, String password) async {
    return await ApiClient.postRequest(Endpoints.login, {
      "notelp": notelp,
      "password": password,
    });
  }
}
