import 'package:get/get.dart';
import '../repositories/login_repository.dart';

class AuthController extends GetxController {
  final AuthRepository authRepository = AuthRepository();
  var isLoading = false.obs;

  Future<void> login(String notelp, String password) async {
    isLoading.value = true;
    try {
      var response = await authRepository.login(notelp, password);
      print(response.data);
    } catch (e) {
      print("Login gagal");
    }
    isLoading.value = false;
  }
}
