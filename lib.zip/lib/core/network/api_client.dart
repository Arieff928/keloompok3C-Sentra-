import 'package:dio/dio.dart';

class ApiClient {
  static final Dio dio = Dio(
    BaseOptions(
      baseUrl: "http://127.0.0.1/api",
      connectTimeout: Duration(seconds: 10),
      receiveTimeout: Duration(seconds: 10),
    ),
  );

  static Future<Response> getRequest(
    String url, {
    Map<String, dynamic>? params,
  }) async {
    try {
      return await dio.get(url, queryParameters: params);
    } catch (e) {
      throw Exception("Failed to load data");
    }
  }

  static Future<Response> postRequest(
    String url,
    Map<String, dynamic> data,
  ) async {
    try {
      return await dio.post(url, data: data);
    } catch (e) {
      throw Exception("Failed to send data");
    }
  }
}
